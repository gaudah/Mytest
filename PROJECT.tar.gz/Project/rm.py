import os

print "trying to rmove"
#os.remove("../../../../../../home/aishu/1.txt")
#os.remove("../../../../../../home/aishu/All_Downloads/filedata")
os.system("rm ../../../../../../home/aishu/All_Downloads/filedata*")
print "it removed"

